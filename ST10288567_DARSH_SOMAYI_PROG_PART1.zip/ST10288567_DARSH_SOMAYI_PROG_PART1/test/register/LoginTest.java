package register;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class LoginTest {

    @Test
    public void testIsUsernameValid_ValidUsername() {
        Login login = new Login("test_user", "Test123!", "John", "Doe");
        assertTrue(login.isUsernameValid("test_user"));
    }

    @Test
    public void testIsUsernameValid_InvalidUsername() {
        Login login = new Login("test_user", "Test123!", "John", "Doe");
        assertFalse(login.isUsernameValid("test"));
    }

    @Test
    public void testIsPasswordValid_ValidPassword() {
        Login login = new Login("test_user", "Test123!", "John", "Doe");
        assertTrue(login.isPasswordValid("Test123!"));
    }

    @Test
    public void testIsPasswordValid_InvalidPassword() {
        Login login = new Login("test_user", "Test123!", "John", "Doe");
        assertFalse(login.isPasswordValid("test"));
    }

    @Test
    public void testRegisterUser_ValidInput() {
        Login login = new Login("test_user", "Test123!", "John", "Doe");
        assertEquals("Registration successful!", login.registerUser("test_user", "Test123!", "John", "Doe"));
    }

    @Test
    public void testRegisterUser_InvalidUsername() {
        Login login = new Login("test_user", "Test123!", "John", "Doe");
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.", login.registerUser("test", "Test123!", "John", "Doe"));
    }

    @Test
    public void testRegisterUser_InvalidPassword() {
        Login login = new Login("test_user", "Test123!", "John", "Doe");
        assertEquals("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.", login.registerUser("test_user", "test", "John", "Doe"));
    }

    @Test
    public void testLoginUser_ValidCredentials() {
        Login login = new Login("test_user", "Test123!", "John", "Doe");
        assertEquals("Welcome John Doe, it is great to see you again.", login.loginUser("test_user", "Test123!"));
    }

    @Test
    public void testLoginUser_InvalidCredentials() {
        Login login = new Login("test_user", "Test123!", "John", "Doe");
        assertEquals("Username or password incorrect, please try again.", login.loginUser("test_user", "WrongPassword"));
    }
}

//References For The Unit Testing:
//https://www.freecodecamp.org/news/java-unit-testing/