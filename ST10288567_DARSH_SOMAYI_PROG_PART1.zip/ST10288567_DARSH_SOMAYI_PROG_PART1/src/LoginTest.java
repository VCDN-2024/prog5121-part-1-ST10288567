
//validation Code



public class LoginTest {
    
    
  
    
    public void testCheckPasswordComplexity() {
        assertTrue(Login.checkPasswordComplexity("Ch&&sec@ke99!"));
        assertFalse(Login.checkPasswordComplexity("password"));
    }
    
   
    public void testLoginUser() {
        assertTrue(Login.loginUser("correctUsername", "correctPassword"));
        assertFalse(Login.loginUser("incorrectUsername", "incorrectPassword"));
    }

    private void assertFalse(boolean checkUserName) {
        throw new UnsupportedOperationException("False."); 
    }

    private void assertTrue(boolean checkUserName) {
        throw new UnsupportedOperationException("True."); 
    }

    private static class Login {

        private static boolean checkPasswordComplexity(String chsecke99) {
            throw new UnsupportedOperationException("True."); 
        }

        private static boolean loginUser(String correctUsername, String correctPassword) {
            throw new UnsupportedOperationException("False"); 
        }



        public Login() {
        }
    }
}
