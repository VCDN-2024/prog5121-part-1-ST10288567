package register;

import javax.swing.JOptionPane;

public class Login {
    private final String username;
    private final String password;
    private final String firstName;
    private final String lastName;

    // Constructor to initialize username, password, first name, and last name
    public Login(String username, String password, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Method to check if username is correctly formatted
    private boolean isUsernameValid(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    // Method to check password complexity
    private boolean isPasswordValid(String password) {
        return password != null && password.length() >= 8 &&
                password.matches(".*[A-Z].*") && password.matches(".*\\d.*") &&
                password.matches(".*[!@#$%^&*()-_=+\\\\|\\[{\\]};:'\",<.>/?].*");
    }

    // Method to register user
    public String registerUser(String username, String password, String firstName, String lastName) {
        if (!isUsernameValid(username)) {
            return "Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than 5 characters in length.";
        } else if (!isPasswordValid(password)) {
            return "Password is not correctly formatted. Please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.";
        } else {
            return "Registration successful!";
        }
    }

    // Method to login user
    public String loginUser(String enteredUsername, String enteredPassword) {
        if (enteredUsername.equals(username) && enteredPassword.equals(password)) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect. Please try again.";
        }
    }

    // Main method
    public static void main(String[] args) {
        // Input username, password, first name, and last name
        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");
        String firstName = JOptionPane.showInputDialog("Enter first name:");
        String lastName = JOptionPane.showInputDialog("Enter last name:");

        // Check if any input is cancelled
        if (username == null || password == null || firstName == null || lastName == null) {
            JOptionPane.showMessageDialog(null, "Input cancelled. Exiting.");
            return;
        }

        // Create Login object with user details
        Login user = new Login(username, password, firstName, lastName);
        
        // Register user and display registration message
        String registrationMessage = user.registerUser(username, password, firstName, lastName);
        JOptionPane.showMessageDialog(null, registrationMessage);

        // Input username and password for login
        String enteredUsername = JOptionPane.showInputDialog("Enter your username:");
        String enteredPassword = JOptionPane.showInputDialog("Enter your password:");

        // Check if login input is cancelled
        if (enteredUsername == null || enteredPassword == null) {
            JOptionPane.showMessageDialog(null, "Input cancelled. Exiting.");
            return;
        }

        // Login user and display login status
        String loginStatus = user.loginUser(enteredUsername, enteredPassword);
        JOptionPane.showMessageDialog(null, loginStatus);
    }
}

//References For The Code:
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21282230-dt-content-rid-121738653_1/xid-121738653_1
//https://myvc.iielearn.ac.za/bbcswebdav/pid-21282230-dt-content-rid-121738651_1/xid-121738651_1